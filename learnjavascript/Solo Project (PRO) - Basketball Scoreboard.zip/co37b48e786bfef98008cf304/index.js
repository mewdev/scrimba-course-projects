let countHome = 0;
let countGuest = 0;
let homeScore = document.getElementById("countHome");
let guestScore = document.getElementById("countGuest");


function resetCount () {
    countHome = 0
    countGuest = 0
    homeScore.textContent = countHome
    guestScore.textContent = countGuest
}

function addOneHome () {
    countHome = countHome + 1
    homeScore.textContent = countHome
}

function addTwoHome () {
    countHome = countHome + 2
    homeScore.textContent = countHome
}

function addThreeHome () {
    countHome = countHome + 3
    homeScore.textContent = countHome
}

function addOneGuest () {
    countGuest = countGuest + 1
    guestScore.textContent = countGuest
}

function addTwoGuest () {
    countGuest = countGuest + 2
    guestScore.textContent = countGuest
}

function addThreeGuest () {
    countGuest = countGuest + 3
    guestScore.textContent = countGuest
}

